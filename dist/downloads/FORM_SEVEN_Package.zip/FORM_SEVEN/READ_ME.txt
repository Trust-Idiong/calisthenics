FORM / SEVEN — Downloadable workout app
Version 2 · 12 October 2026

QUICK START — NO INSTALLATION REQUIRED

1. Extract the entire ZIP into a folder on your computer.
2. Double-click index.html to open the app in Chrome, Edge, Firefox or Safari.
3. Select My goal and enter your actual starting weight. The default target is
   10 kg over seven months, with a stronger core and regular walking.
4. Open Today's workout, watch the movement demonstrations, and start with
   Foundation. Add warm-up time if you have not already warmed up.

Your computer's date becomes the start date on the first use of a new copy.
You can change the start date and target date in My goal.

The timer, exercise instructions, plan, journal and charts work without an
internet connection. Exercise videos, video thumbnails and reference websites
need internet access. Third-party video files are not included in this ZIP.

VIDEOS AND THE TWO WAYS TO RUN THE APP

When you double-click index.html, Watch demo opens a guide with a link to the
original YouTube video in a new tab. The workout pauses while you view a guide.
This avoids the embedding restrictions that some browsers apply to local files.

For embedded videos, use the optional local launcher:

  Windows: double-click START_WINDOWS.bat.
  Mac/Linux with Python 3: python3 start_local.py
  Any system with Node.js: node start_local.mjs

The launcher needs Python 3 or Node.js already installed. It starts the app at
http://127.0.0.1:8765 and opens your browser. Keep its terminal window open while
using the app. Close it or press Ctrl+C when finished. It listens only on your
computer, not your home or office network. If the port is in use, stop the
previous copy or open the app already running at that address.

You can always open index.html directly if you do not have either runtime.

YOUR UPDATED PLAN

- Initial target: 10 kg over seven months, then reassess. This assumes a
  starting weight around 100 kg; enter your current weight and review whether
  the target fits you. A common initial goal is 5–10% of starting weight over
  about six months.
- Strength: gradually build to 2–3 sessions on nonconsecutive days each week.
- Walking: start comfortably and build toward 150 minutes of moderate/brisk
  walking a week. Mark a walk as brisk only for time when you could talk but
  not sing. Easy walks remain in your journal without being counted as brisk.
- Core: follow gradual core exercises and optional waist measurements. There
  is no promised date for visible abdominal muscles.
- Review the first 5 kg lost and reassess your goal after the first 5–10 kg.
  The scale can fluctuate; weekly averages are not a quota or a forecast.

HOW THE WORKOUT PLAYER WORKS

- Foundation: 10 minutes; Core & control: 12 minutes; Full body: 16 minutes.
- Work and rest intervals advance automatically. Use Pause whenever needed.
- The opening warm-up can be extended to six minutes. Extra time is included
  in the displayed session total. Recovery intervals can also be extended.
- A sound marks interval changes; use the sound button to switch it off.
- Leaving the tab or opening a guide pauses your workout.
- A skipped interval makes the workout a partial session. Only elapsed time
  is logged. Resetting an unfinished session discards it after confirmation.
- The Space key starts or pauses a workout when you are not typing or using
  a form control.

YOUR DATA AND BACKUPS

Progress stays in the browser you use. It is not saved into this ZIP or
automatically synchronized between the hosted site, local file and local server.
Keep the app at a consistent file path or use the local launcher consistently.
Private browsing, browser cleanup, moving the file, or switching browsers may
make local records unavailable. Use Export backup regularly.

To bring your existing online progress to this package:
1. Open https://form-seven.tarxyox.chatgpt.site in the browser with your history.
2. Go to Your progress and choose Export backup.
3. Open this local app, go to Your progress, and choose Restore backup.
4. Select that JSON file. Restoring replaces this local copy's current records.

Older version-1 backups are supported. The old default 30 kg goal is migrated
to 10 kg over seven months while keeping the starting weight, dates of activity,
weigh-ins, walking records, workouts and sound setting. Other custom targets
are preserved. Use My goal → Use 10 kg / seven months to reset a custom target.

You can add an optional waist measurement to a weigh-in. A blank waist field
does not erase an existing waist measurement for the same date. Delete that
weigh-in and add it again if you need to remove its waist value.

PACKAGE CONTENTS

index.html             Portable app with its styles, scripts and icon included.
START_WINDOWS.bat      Optional Windows launcher.
start_local.py         Optional Python local server, standard library only.
start_local.mjs        Optional Node local server, built-in modules only.
READ_ME.txt            This guide.
VIDEO_SOURCES.txt      Exercise video credits and health-guidance links.
source/               Editable HTML, CSS, JavaScript, package builder and tests.

No API keys, passwords, hosting credentials or personal workout records are
included. No npm install or build is required to use the portable app.

EDITING AND HOSTING

You can upload index.html by itself to a normal static web host. Alternatively,
use the files in source/dist for a modular version; serve that folder over HTTP
instead of opening its module-based index.html directly from a file path.

To run the included logic checks, open a terminal in source and run:
  node --test tests/engine.test.mjs

To rebuild the portable package from the editable source, run:
  python3 scripts/build-package.py
On Windows, use py -3 in place of python3.

CHECKS AND LIMITS

Timer, date handling, goal migration, backup validation and weekly activity
accounting have automated checks. The portable bundle and ZIP are checked for
syntax, required files and missing local dependencies. Browser rendering,
third-party video playback and Windows launcher execution were not verified
in the build environment. Use the original video links if an embed is blocked.

HEALTH CONTEXT

This is a general fitness tool, not an individual medical or nutrition plan.
Review your goal with a clinician or registered dietitian when appropriate,
especially with a health condition, injury or medication. Move comfortably,
keep breathing, and stop if you feel pain or become unwell. Weight changes and
abdominal definition vary; the app does not guarantee a particular result.
