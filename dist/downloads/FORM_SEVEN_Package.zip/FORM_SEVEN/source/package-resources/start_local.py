"""Serve the portable app on this computer using only Python's standard library."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys
import webbrowser

def main():
    folder = Path(__file__).resolve().parent
    address = ("127.0.0.1", 8765)
    handler = partial(SimpleHTTPRequestHandler, directory=str(folder))
    try:
        server = ThreadingHTTPServer(address, handler)
    except OSError as error:
        print("Could not start FORM / SEVEN:", error)
        print("If another copy is running, open http://127.0.0.1:8765")
        return 1
    print("FORM / SEVEN is available at http://127.0.0.1:8765")
    print("Keep this window open. Press Ctrl+C to stop.")
    webbrowser.open("http://127.0.0.1:8765")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nFORM / SEVEN stopped.")
    finally:
        server.server_close()
    return 0

if __name__ == "__main__":
    sys.exit(main())
