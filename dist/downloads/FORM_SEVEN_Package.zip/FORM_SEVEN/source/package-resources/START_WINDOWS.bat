@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 start_local.py
  goto finished
)
where node >nul 2>&1
if not errorlevel 1 (
  node start_local.mjs
  goto finished
)
echo Python 3 or Node.js was not found. Opening the portable app directly.
echo The timer works locally; video guides open online in a new tab.
start "" "%~dp0index.html"
goto done
:finished
if errorlevel 1 pause
:done
endlocal
