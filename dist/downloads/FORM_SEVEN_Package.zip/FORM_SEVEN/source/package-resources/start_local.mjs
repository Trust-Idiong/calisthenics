// Serve only this package folder on this computer; no dependencies required.
import http from 'node:http';
import {readFile, stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';

const root=path.dirname(fileURLToPath(import.meta.url));
const address='http://127.0.0.1:8765';
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json','.txt':'text/plain; charset=utf-8','.zip':'application/zip'};
const server=http.createServer(async(req,res)=>{
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return;}
  try{
    let requestPath=decodeURIComponent(new URL(req.url,address).pathname);
    if(requestPath.endsWith('/'))requestPath+='index.html';
    const target=path.resolve(root,'.'+requestPath);
    if(!target.startsWith(root+path.sep)){res.writeHead(403);res.end('Forbidden');return;}
    const details=await stat(target);
    if(!details.isFile()){res.writeHead(404);res.end('Not found');return;}
    const bytes=await readFile(target);
    res.writeHead(200,{'Content-Type':mime[path.extname(target)]||'application/octet-stream','Content-Length':bytes.length,'X-Content-Type-Options':'nosniff'});
    res.end(req.method==='HEAD'?undefined:bytes);
  }catch{res.writeHead(404);res.end('Not found');}
});
server.on('error',error=>{
  console.error('Could not start FORM / SEVEN:',error.message);
  console.error('If another copy is running, open '+address);
  process.exitCode=1;
});
server.listen(8765,'127.0.0.1',()=>{
  console.log('FORM / SEVEN is available at '+address+'\nKeep this window open. Press Ctrl+C to stop.');
  let command,args;
  if(process.platform==='win32'){command='cmd';args=['/c','start','',address];}
  else if(process.platform==='darwin'){command='open';args=[address];}
  else{command='xdg-open';args=[address];}
  const child=spawn(command,args,{stdio:'ignore',detached:true});child.on('error',()=>{});child.unref();
});
