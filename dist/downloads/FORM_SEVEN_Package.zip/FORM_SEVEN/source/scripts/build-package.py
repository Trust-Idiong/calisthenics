"""Build a no-install portable HTML app and a clean, editable distribution ZIP."""
from pathlib import Path
import argparse
import base64
import json
import re
import shutil
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]

def build(output):
    source=ROOT/'dist'
    page=(source/'index.html').read_text(encoding='utf-8')
    css=(source/'styles.css').read_text(encoding='utf-8')
    # The portable edition uses system fonts and does not load remote CSS.
    css=re.sub(r'^@import[^;]+;\s*','',css,flags=re.M)
    scripts=[]
    for name in ['engine.js','exercises.js','app.js']:
        script=(source/name).read_text(encoding='utf-8')
        script=re.sub(r'^import\s+[^\n]+\n','',script,flags=re.M)
        script=re.sub(r'^export\s+','',script,flags=re.M)
        scripts.append(script)
    bundle='(function(){\n"use strict";\n'+'\n'.join(scripts)+'\n})();\n'
    icon='data:image/svg+xml;base64,'+base64.b64encode((source/'assets/favicon.svg').read_bytes()).decode('ascii')
    page=page.replace('href="assets/favicon.svg"',f'href="{icon}"').replace('src="assets/favicon.svg"',f'src="{icon}"')
    page=page.replace('<link rel="stylesheet" href="styles.css">','<style>\n'+css+'\n</style>')
    page=page.replace('<script type="module" src="app.js"></script>','<script>\n'+bundle.replace('</script','<\\/script')+'\n</script>')
    page=page.replace('<a id="package-download" class="text-btn" href="downloads/FORM_SEVEN_Package.zip" download>Download app package ↓</a>','<a class="text-btn" href="READ_ME.txt" target="_blank" rel="noopener noreferrer">Package instructions ↗</a>')
    with tempfile.TemporaryDirectory(prefix='form-seven-package-') as temporary:
        folder=Path(temporary)/'FORM_SEVEN';folder.mkdir()
        (folder/'index.html').write_text(page,encoding='utf-8')
        for path in (ROOT/'package-resources').iterdir():
            if not path.is_file():continue
            if path.suffix.lower()=='.bat':
                (folder/path.name).write_bytes(path.read_text(encoding='utf-8').replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))
            else:shutil.copyfile(path,folder/path.name)
        credits=['FORM / SEVEN — Exercise video credits and references','',
                 'Videos are linked to their original providers. Video files are not redistributed.',
                 'The app is independent and has no affiliation with the providers below.','']
        data=(source/'exercises.js').read_text(encoding='utf-8')
        for match in re.finditer(r"name:'([^']+)'.*?video:'([^']+)'.*?provider:'([^']+)'.*?source:'([^']+)'",data):
            name,video,provider,url=match.groups()
            if name=='Easy walking':continue
            credits += [name+' — '+provider,'https://www.youtube.com/watch?v='+video,url,'']
        credits+=['HEALTH GUIDANCE','']
        for title,url in re.findall(r"title:'([^']+)',url:'([^']+)'",data):credits+=[title,url,'']
        (folder/'VIDEO_SOURCES.txt').write_text('\n'.join(credits),encoding='utf-8')
        # Explicit allowlist: no Site identity, Git metadata, credentials or user records.
        selected=[ROOT/'package.json']
        for base in ['dist','tests','scripts','package-resources']:
            selected += [p for p in (ROOT/base).rglob('*') if p.is_file() and 'downloads' not in p.relative_to(ROOT).parts and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.zip','.gz'}]
        for path in selected:
            target=folder/'source'/path.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
        output.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
            for path in sorted(folder.rglob('*')):
                if path.is_file():archive.write(path,path.relative_to(folder.parent).as_posix())
    return {'archive':str(output),'bytes':output.stat().st_size}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'dist/downloads/FORM_SEVEN_Package.zip');args=parser.parse_args()
    print(json.dumps(build(args.output.resolve())))
